"""冷启动地理编码：用 OSM 为「词典里没有的地名」找坐标。

为什么需要它
------------
识别能力的第一道门槛是「知道这些地名在哪」。此前只有两条路：

1. 本地词典 ``data/lexicon.json``——只覆盖已核验过的少量地名；
2. 腾讯/高德/百度/天地图的在线地理编码——需要用户自己申请密钥。

换一个区域就完全无法识别：OCR 明明读出了「安龙小区」「进才实验中学」
这些真实地名，却因为「本地没这个词、也没配密钥」而拿不到任何坐标，
配准直接失败（实测新截图：0 个锚点命中，配准失败）。

本模块补上第三条路：**按城市限定范围去 OSM 检索地名**。
它与项目既有做法完全一致——``app/seed_lexicon.py`` 的初始词典种子
本来就是「viewbox 限定的地理编码查询」得到的。

三阶段策略
----------
**阶段一：多查询变体收集候选**

Nominatim 的索引对前缀/后缀敏感，同一个 POI 换个写法结果就不同：

    进才实验中学   → 0 条
    上海市进才实验中学 → 1 条  ✓

所以每个地名用多个变体检索：``{名} {市}``、``{市}{名}``、``{名}``。

**阶段二：名称相似度打分**

OCR 会截断地名（「进才实验中学」实际是「上海市进才实验中学」，
「水清木华」实际是「水清木华公寓」），因此不能要求完全同名。
用 Jaccard 字符相似度 + 子串加权打分，低于阈值直接丢弃。

**阶段三：多锚点互证定位**

单个地名无法自证位置——「花园2期」能匹配到朗香/星宇/尼德兰/三湘盛世
四个不同小区的「2期」，取哪个都可能错。

但**多个独立检索的地名若彼此都落在 1 公里内**，那这片区域就是真的。
实测浦东一例：华丽家族花园、天安花园、当代清水园、水清木华公寓
四个地名各自独立检索，命中点互相都在 300-500 米内，
由此锁定区域中心 (121.5537, 31.2282)，再用它过滤其余候选。

这个阶段的必要性由一次真实失败推动：早期版本用「完全同名 + 城市级
viewbox」，浦东那张截图 6 个 POI 全部 0 命中——viewbox 对上海市这样
的大范围 bbox 几乎没有过滤作用，同名异地地点混了进来。

合规说明
--------
本模块**只用于底图与地理编码的坐标参考**，不用于底图渲染，
与 ``app/roadfit.py`` 用 OSM 路网做几何精修是同一性质：
提供客观地理几何/坐标，不提供地图画面。
页面底图仍是腾讯地图；在线地理编码优先级仍高于本模块。

精度说明
--------
OSM 的 POI 点位与国内底图（美团/高德/腾讯）同源 POI 可能有 100-300 米偏差。
这正是 ``app/roadfit.py``「路网约束精修」存在的原因：
它用道路几何（各底图必须一致）纠正 POI 锚点带来的整体偏移。
所以本模块的产出被标记为 ``osm`` 源，质量权重低于用户确认与在线服务，
并最终由路网精修兜住绝对位置。
"""

from __future__ import annotations

import json
import math
import re
import threading
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any

from .geo.coords import wgs84_to_gcj02

NOMINATIM = "https://nominatim.openstreetmap.org/search"

# Nominatim 使用政策要求最多 1 次/秒。必须遵守，
# 否则会被封 IP——这个项目是单机自用工具，封了就彻底没法冷启动了。
_MIN_INTERVAL = 1.05

# 名称相似度阈值：低于此值直接丢弃。
# 定这个值是因为「何文田上海水配水庫」与「乡土田园区」的相似度只有 0.08，
# 而「水清木华公寓」与「水清木华」是 0.92。0.55 落在中间，且不误伤。
_MIN_NAME_SCORE = 0.55

# 互证半径（米）：候选点彼此的距离小于它，才算互相印证。
# 取 800 是因为「同一小区群内不同楼栋」的距离就在这个量级，
# 而不同街区的同名地点通常隔 1 公里以上。
_CORROBORATE_RADIUS_M = 800.0

# 锚点与区域中心的最大允许距离（米）。
# 超过说明该候选不属于这个区域——比如「花园2期」在别的区也有。
_MAX_CENTER_DIST_M = 1500.0

# 每个地名保留的候选数上限。
#
# 放宽到 5（早期是 3）：候选筛选的正确性交给 RANSAC 的几何一致性，
# 候选多给它几份选择，RANSAC 才能挑出自洽的那一组。
# 实测上海古北一例，正是因为过早截断，正确的候选没能进入配准。
_MAX_CANDIDATES_PER_NAME = 5

# 城市范围裁剪的余量（度）。0.25° 约合 25 公里，
# 足以覆盖上海周边的卫星城，又能把哈尔滨/成都这类异地同名地点挡掉。
_CITY_BBOX_PAD_DEG = 0.25


@dataclass
class OsmPlace:
    """OSM 检索到的一个地点。"""

    name: str
    lon: float  # GCJ-02
    lat: float  # GCJ-02
    kind: str  # poi / transit / other
    score: float = 1.0  # 与 OCR 名的相似度
    osm_type: str = ""
    osm_id: int = 0

    @property
    def is_poi(self) -> bool:
        return self.kind == "poi"


def normalize_city(city: str) -> str:
    """把用户输入的城市规整成检索用的名字。

    「北京」「上海」「天津」「重庆」四个直辖市补「市」后更稳。
    """
    c = (city or "").strip()
    if not c:
        return ""
    if c.endswith(("市", "区", "县")):
        return c
    if c in ("北京", "上海", "天津", "重庆"):
        return c + "市"
    return c


def _city_stem(city: str) -> str:
    """去掉「市」后缀，得到「上海」这样的短名。"""
    c = normalize_city(city)
    return c[:-1] if c.endswith("市") else c


def name_score(ocr: str, cand: str) -> float:
    """OCR 名与 OSM 候选名的相似度（0~1）。

    真实案例说明为什么不能要求完全同名：
      OCR「进才实验中学」 → OSM「上海市进才实验中学」（前缀被截）
      OCR「水清木华」     → OSM「水清木华公寓」（后缀被截）
      OCR「花园2期」     → OSM「朗香花园2期」（中间被截）
    """
    if not ocr or not cand:
        return 0.0
    if ocr == cand:
        return 1.0
    if ocr in cand:
        # OCR 名是候选名的子串：按覆盖比例给分，完整覆盖给 1.0
        return 0.75 + 0.25 * len(ocr) / len(cand)
    if cand in ocr:
        return 0.70
    sa, sb = set(ocr), set(cand)
    return len(sa & sb) / max(len(sa | sb), 1) * 0.9


def _haversine_m(lon1: float, lat1: float, lon2: float, lat2: float) -> float:
    """两点距离（米）。"""
    r = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = p2 - p1
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


class ColdStartGeocoder:
    """按城市检索 OSM 地名，返回候选坐标。

    带进程内缓存与磁盘缓存，避免同一地名反复打网络。
    """

    def __init__(self, cache_path: str | None = None):
        self.cache_path = cache_path
        self._mem: dict[str, list[OsmPlace]] = {}
        self._lock = threading.RLock()
        self._last_call = 0.0
        self._bbox_cache: dict[str, tuple[float, float, float, float]] = {}
        if cache_path:
            self._load_disk()

    # ---------- 缓存 ----------

    def _load_disk(self) -> None:
        try:
            with open(self.cache_path, encoding="utf-8") as f:
                raw = json.load(f)
        except (OSError, json.JSONDecodeError):
            return
        for key, items in raw.items():
            self._mem[key] = [
                OsmPlace(
                    name=p["name"], lon=p["lon"], lat=p["lat"],
                    kind=p.get("kind", "poi"), score=p.get("score", 1.0),
                    osm_type=p.get("osm_type", ""), osm_id=p.get("osm_id", 0),
                )
                for p in items
            ]

    def _save_disk(self) -> None:
        if not self.cache_path:
            return
        try:
            with open(self.cache_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        k: [
                            {"name": p.name, "lon": p.lon, "lat": p.lat,
                             "kind": p.kind, "score": p.score,
                             "osm_type": p.osm_type, "osm_id": p.osm_id}
                            for p in v
                        ]
                        for k, v in self._mem.items()
                    },
                    f, ensure_ascii=False,
                )
        except OSError:
            pass

    # ---------- 网络 ----------

    def _throttle(self) -> None:
        with self._lock:
            wait = _MIN_INTERVAL - (time.time() - self._last_call)
            if wait > 0:
                time.sleep(wait)
            self._last_call = time.time()

    def _request(self, params: dict[str, Any]) -> list[dict]:
        url = NOMINATIM + "?" + urllib.parse.urlencode(params)
        req = urllib.request.Request(
            url, headers={"User-Agent": "meituan-ride/0.1 (self-hosted local tool)"}
        )
        try:
            with urllib.request.urlopen(req, timeout=25) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except Exception:  # noqa: BLE001 — 网络失败不应让整次识别崩掉
            return []

    def city_bbox(self, city: str) -> tuple[float, float, float, float] | None:
        """取城市的经纬度范围（WGS-84）。

        Nominatim 返回的 boundingbox 顺序是 [south, north, west, east]。
        """
        cname = normalize_city(city)
        if not cname:
            return None
        with self._lock:
            if cname in self._bbox_cache:
                return self._bbox_cache[cname]
        self._throttle()
        data = self._request({
            "q": cname, "format": "jsonv2", "limit": 1,
            "countrycodes": "cn", "accept-language": "zh-CN",
        })
        if not data:
            return None
        b = data[0].get("boundingbox")
        if not b or len(b) != 4:
            return None
        try:
            south, north, west, east = (float(x) for x in b)
        except (TypeError, ValueError):
            return None
        bbox = (west, south, east, north)
        with self._lock:
            self._bbox_cache[cname] = bbox
        return bbox

    def _variants(self, name: str, city: str) -> list[str]:
        """构造查询变体。

        Nominatim 的索引对前缀敏感：「进才实验中学」查不到，
        「上海市进才实验中学」能查到。所以要多试几种写法。

        但每个变体都要付 1 秒限速的代价，因此按「最可能命中」排序，
        并在前两个变体就查到足够候选时提前返回。
        """
        cname = normalize_city(city)
        stem = _city_stem(city)
        out = [
            f"{name} {cname}",
            f"{cname}{name}",
            f"{stem}{name}",
            name,
        ]
        seen: set[str] = set()
        res: list[str] = []
        for v in out:
            if v and v not in seen:
                seen.add(v)
                res.append(v)
        return res

    def _classify(self, raw_name: str, d: dict) -> str:
        """判断 OSM 要素能否作配准锚点，并给出更精确的类型。

        类型决定配准时的内点容差：行政区标注点与几何质心可差 1-2 公里，
        车站/POI 则只差几十米。混为一谈会让正确的锚点被判成离群。
        """
        from .geocode import infer_kind

        cat = (d.get("category") or "").strip()
        osm_class = (d.get("type") or "").strip()
        kind = infer_kind(raw_name, cat, osm_class)
        if kind in ("poi", "district", "station"):
            return kind
        # 道路/水系：文字沿走向排布，中心不对应固定点位，但**高架与快速路
        # 在城市级截图里是极好的线性锚点**（Nominatim 返回的是路上一处
        # 带名字的节点），因此保留为 road 而不是丢弃。
        if kind == "road":
            return "road"
        if cat in ("highway", "waterway") or osm_class in ("road",):
            return "road"
        if cat in ("public_transport", "railway") or "地铁" in raw_name \
                or "号线" in raw_name or raw_name.endswith("站"):
            return "transit"
        return "poi"

    def _in_city(
        self, lon: float, lat: float, bbox, is_wgs84: bool = True
    ) -> bool:
        """候选是否落在城市范围内（允许一定余量）。

        Nominatim 的 viewbox 只是**排序提示**，不做强制过滤，同名异地
        地点照样会返回。实测城市级截图里的「3号线」匹配到哈尔滨、
        「8号线」匹配到重庆、「1号线」匹配到成都——这些点离真实轨迹
        上千公里，一旦被误当作内点，配准就会整个跑偏。

        这里做硬性距离裁剪：超出城市范围（含余量）的候选直接丢弃。
        """
        if not bbox:
            return True
        if not is_wgs84:
            from .geo.coords import gcj02_to_wgs84

            lon, lat = gcj02_to_wgs84(lon, lat)
        west, south, east, north = bbox
        pad = _CITY_BBOX_PAD_DEG
        return (
            west - pad <= lon <= east + pad
            and south - pad <= lat <= north + pad
        )

    def _collect_candidates(
        self, name: str, city: str, min_hits: int = 3
    ) -> list[OsmPlace]:
        """阶段一 + 二：多变体检索 + 相似度打分。

        ``min_hits``：查到这么多候选就停止试后续变体。
        每个变体要付 1 秒限速的代价，而 3 个候选已足够 RANSAC 挑选。
        """
        bbox = self.city_bbox(city)
        best: dict[tuple[float, float], OsmPlace] = {}
        for q in self._variants(name, city):
            params: dict[str, Any] = {
                "q": q,
                "format": "jsonv2",
                "limit": 20,
                "countrycodes": "cn",
                "accept-language": "zh-CN",
            }
            if bbox:
                # viewbox 只是排序提示，**不做强制过滤**——实测它对
                # 上海市这种大范围 bbox 几乎不起作用，同名异地地点照样返回。
                # 真正的过滤由阶段三的互证负责。
                params["viewbox"] = f"{bbox[0]},{bbox[1]},{bbox[2]},{bbox[3]}"
            self._throttle()
            for d in self._request(params):
                raw_name = (d.get("name") or "").strip()
                if not raw_name:
                    continue
                s = name_score(name, raw_name)
                if s < _MIN_NAME_SCORE:
                    continue
                try:
                    lon = float(d["lon"])
                    lat = float(d["lat"])
                except (KeyError, TypeError, ValueError):
                    continue
                # 异地同名地点直接丢弃（如「3号线」在哈尔滨）
                if not self._in_city(lon, lat, bbox):
                    continue
                key = (round(lon, 4), round(lat, 4))
                prev = best.get(key)
                if prev is None or s > prev.score:
                    glon, glat = wgs84_to_gcj02(lon, lat)
                    best[key] = OsmPlace(
                        name=raw_name, lon=glon, lat=glat,
                        kind=self._classify(raw_name, d), score=s,
                        osm_type=d.get("osm_type") or "",
                        osm_id=int(d.get("osm_id") or 0),
                    )
            # 已经拿到足够候选就不用再试其他写法了
            if len(best) >= min_hits:
                break
        return sorted(best.values(), key=lambda p: -p.score)

    @staticmethod
    def _find_region_center(
        cands: dict[str, list[OsmPlace]],
        pixels: dict[str, tuple[float, float]] | None = None,
    ) -> tuple[float, float, set[str]] | None:
        """阶段三：多锚点互证，找出互相印证的区域中心。

        判据：候选点周边有 ≥1 个**其他地名**的候选在 800 米内。
        取印证数量最多、总距离最小的那个点作为区域中心。

        返回的第三个元素是「被印证的地名集合」——**包含簇心自身的地名**。
        簇心选在某个候选点上，那个地名本身就是互证的一环：
        「进才实验中学」与「水清木华公寓」相距 500 米，
        以其中一个为簇心时，另一个在 800 米内 → 互证成立。

        为什么 1 个就够：实测浦东一例只有两个地名能查到（其余 4 个
        在 OSM 未收录），但「进才实验中学」与「水清木华公寓」互为印证
        且相距仅 500 米——两个独立检索的地名落在同一片区域，
        这本身就是很强的证据。要求 ≥2 个反而会让这类区域定位失败。

        注意互证是**双向**的：单看「进才实验中学」周围有「水清木华」，
        而「水清木华」周围也有「进才实验中学」，两者都成立。
        而「花园2期」的四个候选（星宇/朗香/尼德兰/三湘盛世花园2期）
        彼此相距 2-5 公里，谁也不印证谁——正是这个差别把它们区分开了。
        """
        flat: list[tuple[float, float, str]] = []
        for ocr, lst in cands.items():
            for p in lst:
                flat.append((p.lon, p.lat, ocr))
        if len(flat) < 2:
            return None

        def orientation_score(lon: float, lat: float, ocr: str) -> float:
            """候选点与多少个「其他地名」的方位关系不矛盾。

            有像素信息时，**南北关系是硬性要求**（图上的上下必须与
            地理上的南北一致）；没有像素信息时退回「距离在互证半径内」。

            为什么像素方位比地理距离更可靠：实测上海古北一例，
            「虹桥基金小镇」与「红松东路」相距仅 791 米，比正确的那一对
            （世贸商城↔大悦城，2379 米）更紧密。只看距离必然选错簇心，
            于是两个正确候选被过滤掉。而像素方位显示
            大悦城在最北、世贸商城居中、基金小镇在最南——
            只有「世贸商城 + 大悦城」这一组满足方位一致性。
            """
            agree = 0.0
            for lo2, la2, o2 in flat:
                if o2 == ocr:
                    continue
                if pixels:
                    py = pixels.get(ocr, (0.0, 0.0))[1]
                    oy = pixels.get(o2, (0.0, 0.0))[1]
                    if (py < oy) != (lat > la2):
                        continue      # 南北关系矛盾 → 该组合不成立
                    agree += 1.0
                else:
                    if _haversine_m(lon, lat, lo2, la2) <= _CORROBORATE_RADIUS_M:
                        agree += 1.0
            return agree

        best: tuple[Any, float, float, set[str]] | None = None
        for lon, lat, ocr in flat:
            agree = orientation_score(lon, lat, ocr)
            if agree <= 0:
                continue
            near = [
                (o2, d) for lo2, la2, o2 in flat
                if o2 != ocr
                and (d := _haversine_m(lon, lat, lo2, la2)) <= _CORROBORATE_RADIUS_M
            ]
            distinct = {o2 for o2, _ in near}
            if not distinct:
                continue
            # 印证的地名集合包含簇心自身的地名——它本身也是互证的一环
            corroborated = distinct | {ocr}
            total_d = sum(d for _, d in near)
            # 排序键：方位一致性优先，其次印证数量，最后总距离。
            key = (agree, len(corroborated), -total_d)
            if best is None or key > (best[0], best[1], best[2]):
                best = (agree, len(corroborated), -total_d, lon, lat, corroborated)
        if best is None:
            return None
        return best[3], best[4], best[5]

    def lookup_many(
        self, names: list[str], city: str = "",
        pixels: dict[str, tuple[float, float]] | None = None,
    ) -> dict[str, list[OsmPlace]]:
        """批量检索多个地名（含互证定位）。

        这是对外的主入口：单锚点无法自证位置，必须成批处理。

        互证需要至少 3 个不同地名才有意义。待查地名不足 3 个时，
        直接用各自的最佳候选——由 RANSAC 的几何一致性兜底。

        **pixels**（可选）：每个地名在截图上的像素位置 (px, py)。
        传入后会启用**位置一致性校验**——见 ``_filter_by_pixel_geometry``。
        """
        if not names or not city:
            return {}

        cands: dict[str, list[OsmPlace]] = {}
        for n in names:
            key = f"{normalize_city(city)}|{n}"
            with self._lock:
                hit = self._mem.get(key)
            if hit is not None:
                cands[n] = hit
                continue
            got = self._collect_candidates(n, city)
            cands[n] = got
            with self._lock:
                self._mem[key] = got
        self._save_disk()

        # 城市范围过滤：**在缓存命中之后也必须做**。
        # 磁盘缓存是长期存在的，里面可能存着过滤规则上线之前写入的
        # 异地同名地点（「3号线」在哈尔滨）。若只在新查询时过滤，
        # 这些陈旧候选会被永久复用，直到用户手动删缓存。
        #
        # 这里只复用**已经取到过的**城市 bbox（`_collect_candidates`
        # 查询时已经填过），不额外发起网络请求——bbox 缺失时退化为
        # 不过滤，行为与旧版一致。
        bbox = getattr(self, "_bbox_cache", {}).get(normalize_city(city))
        if bbox:
            cands = {
                n: [p for p in lst if self._in_city(p.lon, p.lat, bbox, is_wgs84=False)]
                for n, lst in cands.items()
            }
            cands = {n: lst for n, lst in cands.items() if lst}

        # 待查地名太少 → 互证无从谈起，直接给最佳候选。
        # 1 个地名时确实无从互证；2 个是可以的（双向印证，见 _find_region_center）。
        if len([n for n, lst in cands.items() if lst]) < 2:
            return {n: lst[:3] for n, lst in cands.items() if lst}

        center = self._find_region_center(cands, pixels)
        if center is None:
            # 互证失败：退回「每个地名各自的最佳候选」。
            # RANSAC 会用几何一致性挑出自洽的那一组。
            out = {n: lst[:3] for n, lst in cands.items() if lst}
            if pixels:
                out = self._filter_by_pixel_geometry(out, pixels)
            return out

        # ⚠️ 顺序很关键：位置一致性校验必须在「按簇心距离过滤」**之前**做。
        #
        # 原因：簇心本身可能就是错的（只按地理距离选出的一对恰好更紧密），
        # 此时按簇心过滤会把正确候选直接丢掉，后面再怎么校验也救不回来。
        # 实测上海古北一例：互证簇心落在南边的错误区域，
        # 「上海世贸商城」距簇心 2399m、「上海长风大悦城」4471m，
        # 两者在距离过滤阶段就被丢弃了。
        if pixels:
            cands = self._filter_by_pixel_geometry(cands, pixels)

        clon, clat, corroborated = center
        # 簇心过滤**放宽**为「不丢弃，只排序」。
        #
        # 早期实现是硬过滤：距簇心超过 1500 米的候选直接扔掉。
        # 但簇心本身可能是错的——只看地理距离时，
        # 恰好是「地理上更紧密但方位不对」的那一对会赢得簇心，
        # 于是**正确**的候选被扔掉，错的反而留下。
        #
        # 实测上海古北一例：簇心落在「虹桥基金小镇/红松东路」那片
        # 错误区域（相距仅 791m，比正确的那对 2379m 更紧密），
        # 于是「上海世贸商城」（距簇心 2399m）与
        # 「上海长风大悦城」（4471m）被丢弃——
        # 而它们恰恰是唯一正确的两个。
        #
        # 现在改为：按到簇心的距离排序，靠前的优先，
        # 但**不丢弃**远处候选。挑选的正确性交给 RANSAC——
        # 它本来就靠几何一致性判断哪一组候选自洽，
        # 而且做得比这里的距离启发式好得多
        # （实测同一组数据，RANSAC 直接用全部候选可得 RMSE 11.7m、3 内点）。
        out: dict[str, list[OsmPlace]] = {}
        for n, lst in cands.items():
            if not lst:
                continue
            ordered = sorted(
                lst,
                key=lambda q: _haversine_m(clon, clat, q.lon, q.lat),
            )
            # 远处的候选排在后面但仍然保留（RANSAC 会用它们做交叉验证）
            out[n] = ordered[:_MAX_CANDIDATES_PER_NAME]
        return out

    @staticmethod
    def _filter_by_pixel_geometry(
        cands: dict[str, list[OsmPlace]],
        pixels: dict[str, tuple[float, float]],
    ) -> dict[str, list[OsmPlace]]:
        """用「像素相对位置」校验候选，剔除地理上装得下但图上装不下的组合。

        为什么需要这个
        --------------
        互证机制只看**地理距离**：候选点周边有别的地名的候选在 800 米内，
        就认为那一片区域是真的。但这个判据会选错簇心。

        实测事故（上海古北一例）：截图上有 4 个可查到的 POI——
        上海世贸商城、上海长风大悦城、虹桥基金小镇、红松东路。
        其中「虹桥基金小镇」与「红松东路」相距仅 791 米，
        比「上海世贸商城」与「上海长风大悦城」的 2379 米更紧密，
        于是互证把簇心定在了南边那片**错误**区域，
        随即把两个**正确**的候选（世贸商城 2399m、大悦城 4471m）过滤掉了。

        漏掉的关键信息是**像素位置**：
        截图上「上海长风大悦城」在最上方（y=206），
        「虹桥基金小镇」在最下方（y=2521）；
        真实纬度也确实是 31.2227 → 31.1829 单调递减。
        像素的相对关系与地理的相对关系**必须一致**，
        否则这个候选组合就不可能是这张截图。

        做法
        ----
        对每一对「都有候选」的地名，比较它们在像素上的先后/左右关系，
        与候选地理坐标上的南北/东西关系是否一致。
        只保留与**多数**地名关系一致的候选；孤立的矛盾候选被剔除。

        注意：北向朝上的截图才成立。若配准结果 rotation_deg 明显非零，
        说明图被旋转过，此时像素的上下关系不再对应南北，应跳过本校验。
        """
        # 只在双方都有候选的地名之间做比较
        usable = {n: lst for n, lst in cands.items()
                  if lst and n in pixels}
        if len(usable) < 2:
            return cands

        # 对每个地名，统计它的候选与「其他地名的最佳候选」在方位上
        # 有多少处一致。取一致数最高的候选；平手时保留原有的全部。
        best: dict[str, list[OsmPlace]] = {}
        for name, lst in usable.items():
            px, py = pixels[name]
            scores: list[tuple[int, OsmPlace]] = []
            for cand in lst:
                agree = 0
                total = 0
                for other, olst in usable.items():
                    if other == name:
                        continue
                    ox, oy = pixels[other]
                    # 对方取地理上「最近」的候选作参照
                    near = min(olst, key=lambda o: _haversine_m(
                        cand.lon, cand.lat, o.lon, o.lat))
                    # 像素上的南北/东西关系
                    px_north = py < oy
                    px_east = px > ox
                    # 地理上的南北/东西关系
                    geo_north = cand.lat > near.lat
                    geo_east = cand.lon > near.lon
                    total += 1
                    if px_north == geo_north:
                        agree += 1
                    # 东西关系权重低些：图上横向可能有缩放/轻微旋转
                    elif px_east == geo_east:
                        agree += 0.5
                scores.append((agree, cand))
            if not scores:
                continue
            top = max(s for s, _ in scores)
            # 与最高分并列的候选都保留（可能是同地点的多个写法）
            best[name] = [c for s, c in scores if s >= top - 1e-9]

        out = dict(cands)
        for name, lst in best.items():
            if lst:
                out[name] = lst
        return out

    def lookup(
        self, name: str, city: str = "", kinds: tuple[str, ...] = ("poi",)
    ) -> list[OsmPlace]:
        """检索单个地名（不保证互证，仅作兼容入口）。"""
        res = self.lookup_many([name], city)
        return [p for p in res.get(name, []) if p.kind in kinds]


# 进程级单例：磁盘缓存路径由调用方注入
_COLD: ColdStartGeocoder | None = None
_COLD_LOCK = threading.Lock()


def get_cold_start(cache_path: str | None = None) -> ColdStartGeocoder:
    global _COLD
    with _COLD_LOCK:
        if _COLD is None:
            _COLD = ColdStartGeocoder(cache_path)
        return _COLD
